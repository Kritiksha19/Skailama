import { useMemo } from "react";
import PropTypes from "prop-types";
import "./FrameComponent5.css";

const FrameComponent5 = ({
  className = "",
  upload,
  propDebugCommit,
  propDebugCommit1,
  onHomeIconClick,
  onSampleProjectClick,
}) => {
  const languageSelectorStyle = useMemo(() => {
    return {
      debugCommit: propDebugCommit,
    };
  }, [propDebugCommit]);

  const projectTypeSelectorStyle = useMemo(() => {
    return {
      debugCommit: propDebugCommit1,
    };
  }, [propDebugCommit1]);

  return (
    <div className={`title-wrapper-parent ${className}`}>
      <div className="title-wrapper">
        <div className="home-parent">
          <img
            className="home-icon1"
            loading="lazy"
            alt=""
            src="/home.svg"
            onClick={onHomeIconClick}
          />
          <div
            className="sample-project-container1"
            onClick={onSampleProjectClick}
          >
            <span>/ Sample Project /</span>
            <span className="span1">{`  `}</span>
            <span className="upload4">{upload}</span>
          </div>
        </div>
      </div>
      <div className="language-bar">
        <div className="language-selector" style={languageSelectorStyle}>
          <div className="language-dropdown1">
            <img
              className="at-vero-eos-et-accusamus-et-iu"
              loading="lazy"
              alt=""
              src="/vector1.svg"
            />
          </div>
          <div className="language-code">
            <a className="en">EN</a>
          </div>
          <div className="india">
            <div className="weekly-best-sellers">
              <img className="finest-icon" alt="" src="/vector-11.svg" />
              <img className="vector-icon1" alt="" src="/vector-21.svg" />
              <img className="our-selection-icon" alt="" src="/vector-3.svg" />
              <img
                className="group-icon3"
                loading="lazy"
                alt=""
                src="/group-1.svg"
              />
            </div>
          </div>
        </div>
        <div className="project-name1">
          <div
            className="project-type-selector"
            style={projectTypeSelectorStyle}
          >
            <img
              className="icon-bell2"
              loading="lazy"
              alt=""
              src="/-icon-bell.svg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

FrameComponent5.propTypes = {
  className: PropTypes.string,
  upload: PropTypes.string,

  /** Style props */
  propDebugCommit: PropTypes.any,
  propDebugCommit1: PropTypes.any,

  /** Action props */
  onHomeIconClick: PropTypes.func,
  onSampleProjectClick: PropTypes.func,
};

export default FrameComponent5;
