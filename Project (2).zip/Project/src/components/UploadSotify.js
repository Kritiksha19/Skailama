import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./UploadSotify.css";

const UploadSotify = ({ className = "", onClose }) => {
  const navigate = useNavigate();

  const onButtonContainerClick = useCallback(() => {
    navigate("/upload-sp");
  }, [navigate]);

  return (
    <div className={`upload-sotify ${className}`}>
      <section className="frame-parent">
        <div className="frame-group">
          <div className="frame-container">
            <div className="frame-wrapper">
              <div className="frame-div">
                <div className="group-wrapper">
                  <img
                    className="group-icon"
                    loading="lazy"
                    alt=""
                    src="/group.svg"
                  />
                </div>
                <div className="name">Name:</div>
              </div>
            </div>
            <h2 className="upload-from-spotify">Upload from Spotify</h2>
          </div>
          <div className="cross-wrapper">
            <img
              className="cross-icon"
              loading="lazy"
              alt=""
              src="/cross.svg"
            />
          </div>
        </div>
        <input className="input-field1" type="text" />
      </section>
      <section className="description-group">
        <div className="description1">Description:</div>
        <div className="input-field2" />
      </section>
      <div className="button-container">
        <div className="button1" onClick={onButtonContainerClick}>
          <div className="save1">Save</div>
        </div>
      </div>
    </div>
  );
};

UploadSotify.propTypes = {
  className: PropTypes.string,
  onClose: PropTypes.func,
};

export default UploadSotify;
