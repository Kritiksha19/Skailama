import PropTypes from "prop-types";
import "./ChatbotFieldLabels.css";

const ChatbotFieldLabels = ({ className = "", chatbotName }) => {
  return (
    <div className={`chatbot-field-labels ${className}`}>
      <h3 className="chatbot-name">{chatbotName}</h3>
      <div className="field4">
        <input className="label5" placeholder="Placeholder" type="text" />
      </div>
    </div>
  );
};

ChatbotFieldLabels.propTypes = {
  className: PropTypes.string,
  chatbotName: PropTypes.string,
};

export default ChatbotFieldLabels;
