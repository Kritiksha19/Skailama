import { useCallback } from "react";
import FrameComponent from "./FrameComponent";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./UploadYT.css";

const UploadYT = ({ className = "", onClose }) => {
  const navigate = useNavigate();

  const onButtonContainerClick = useCallback(() => {
    navigate("/upload-sp");
  }, [navigate]);

  return (
    <div className={`upload-yt ${className}`}>
      <FrameComponent />
      <section className="description-parent">
        <div className="description">Description:</div>
        <div className="input-field" />
      </section>
      <div className="button-wrapper">
        <div className="button" onClick={onButtonContainerClick}>
          <div className="save">Save</div>
        </div>
      </div>
    </div>
  );
};

UploadYT.propTypes = {
  className: PropTypes.string,
  onClose: PropTypes.func,
};

export default UploadYT;
