import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./ConfigurationOptions.css";

const ConfigurationOptions = ({ className = "" }) => {
  const navigate = useNavigate();

  const onDisplayTextClick = useCallback(() => {
    navigate("/widget-configuration-2");
  }, [navigate]);

  return (
    <div className={`configuration-options ${className}`}>
      <div className="options-list">
        <div className="options-divider" />
        <div className="options-items">
          <div className="option-item">
            <div className="general-option">
              <h2 className="general1">General</h2>
            </div>
            <img
              className="option-item-child"
              loading="lazy"
              alt=""
              src="/line-5.svg"
            />
          </div>
          <div className="display-option">
            <h2 className="display1" onClick={onDisplayTextClick}>
              Display
            </h2>
          </div>
          <h2 className="advanced1">Advanced</h2>
        </div>
      </div>
    </div>
  );
};

ConfigurationOptions.propTypes = {
  className: PropTypes.string,
};

export default ConfigurationOptions;
