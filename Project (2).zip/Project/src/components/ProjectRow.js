import { useMemo } from "react";
import PropTypes from "prop-types";
import "./ProjectRow.css";

const ProjectRow = ({
  className = "",
  propTop,
  propLeft,
  propPadding,
  propPadding1,
  propMargin,
  onProjectRowContainerClick,
}) => {
  const projectRowStyle = useMemo(() => {
    return {
      top: propTop,
      left: propLeft,
      padding: propPadding,
    };
  }, [propTop, propLeft, propPadding]);

  const projectDetailsStyle = useMemo(() => {
    return {
      padding: propPadding1,
    };
  }, [propPadding1]);

  const sPStyle = useMemo(() => {
    return {
      margin: propMargin,
    };
  }, [propMargin]);

  return (
    <div
      className={`project-row ${className}`}
      onClick={onProjectRowContainerClick}
      style={projectRowStyle}
    >
      <div className="project-details" style={projectDetailsStyle}>
        <div className="project-name">
          <div className="project-name-child" />
          <b className="sp" style={sPStyle}>
            SP
          </b>
        </div>
        <div className="episode-count">
          <div className="last-updated">
            <div className="timestamp">
              <b className="sample-project">Sample Project</b>
              <div className="episodes">4 Episodes</div>
            </div>
            <div className="last-edited-a">Last edited a week ago</div>
          </div>
        </div>
      </div>
    </div>
  );
};

ProjectRow.propTypes = {
  className: PropTypes.string,

  /** Style props */
  propTop: PropTypes.any,
  propLeft: PropTypes.any,
  propPadding: PropTypes.any,
  propPadding1: PropTypes.any,
  propMargin: PropTypes.any,

  /** Action props */
  onProjectRowContainerClick: PropTypes.func,
};

export default ProjectRow;
