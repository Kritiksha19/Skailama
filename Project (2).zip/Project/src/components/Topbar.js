import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./Topbar.css";

const Topbar = ({ className = "" }) => {
  const navigate = useNavigate();

  const onWorkspaceContainerClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  return (
    <section className={`topbar ${className}`}>
      <div className="left-sidebar">
        <header className="canvas">
          <div className="workspace" onClick={onWorkspaceContainerClick}>
            <img
              className="screenshot-2024-05-31-130846-12"
              loading="lazy"
              alt=""
              src="/screenshot-20240531-130846-1@2x.png"
            />
            <a className="lama2">LAMA.</a>
          </div>
          <div className="settings">
            <div className="icon-cog1">
              <img className="icon" loading="lazy" alt="" src="/vector.svg" />
            </div>
            <img
              className="divider-icon"
              loading="lazy"
              alt=""
              src="/-icon-bell.svg"
            />
          </div>
        </header>
      </div>
    </section>
  );
};

Topbar.propTypes = {
  className: PropTypes.string,
};

export default Topbar;
