import { useState, useMemo, useCallback } from "react";
import UploadYT from "/";
import PortalPopup from "./PortalPopup";
import UploadSotify from "./UploadSotify";
import PropTypes from "prop-types";
import "./FrameComponent2.css";

const FrameComponent2 = ({
  className = "",
  showFrameDiv,
  propWidth,
  propPadding,
  propFlex,
  propTextDecoration,
  propFontWeight,
  propFlex1,
  propPadding1,
  propMinWidth,
  propWidth1,
  propFlex2,
  propHeight,
  propPadding2,
  propFlex3,
  propMaxHeight,
  propHeight1,
}) => {
  const [isUploadYTOpen, setUploadYTOpen] = useState(false);
  const [isUploadSotifyOpen, setUploadSotifyOpen] = useState(false);
  const frameDivStyle = useMemo(() => {
    return {
      width: propWidth,
      padding: propPadding,
      flex: propFlex,
    };
  }, [propWidth, propPadding, propFlex]);

  const uploadYoutubeVideoContainerStyle = useMemo(() => {
    return {
      textDecoration: propTextDecoration,
      fontWeight: propFontWeight,
    };
  }, [propTextDecoration, propFontWeight]);

  const frameDiv1Style = useMemo(() => {
    return {
      flex: propFlex1,
      padding: propPadding1,
      minWidth: propMinWidth,
      width: propWidth1,
    };
  }, [propFlex1, propPadding1, propMinWidth, propWidth1]);

  const frameDiv2Style = useMemo(() => {
    return {
      flex: propFlex2,
      height: propHeight,
    };
  }, [propFlex2, propHeight]);

  const fileIconStyle = useMemo(() => {
    return {
      padding: propPadding2,
    };
  }, [propPadding2]);

  const componentStatusIconStyle = useMemo(() => {
    return {
      flex: propFlex3,
      maxHeight: propMaxHeight,
      height: propHeight1,
    };
  }, [propFlex3, propMaxHeight, propHeight1]);

  const openUploadYT = useCallback(() => {
    setUploadYTOpen(true);
  }, []);

  const closeUploadYT = useCallback(() => {
    setUploadYTOpen(false);
  }, []);

  const openUploadSotify = useCallback(() => {
    setUploadSotifyOpen(true);
  }, []);

  const closeUploadSotify = useCallback(() => {
    setUploadSotifyOpen(false);
  }, []);

  return (
    <>
      <div className={`recipes-wrapper ${className}`} style={frameDivStyle}>
        <div className="recipes">
          <div className="tradition" onClick={openUploadYT}>
            <img
              className="youtube-icon1"
              loading="lazy"
              alt=""
              src="/youtube1.svg"
            />
            <a
              className="upload-youtube-video-container"
              style={uploadYoutubeVideoContainerStyle}
            >
              <p className="upload5">Upload</p>
              <p className="youtube-video">Youtube Video</p>
            </a>
          </div>
          <div className="header-labels" onClick={openUploadSotify}>
            <img
              className="group-icon4"
              loading="lazy"
              alt=""
              src="/group-2.svg"
            />
            <b className="upload-spotify-podcast-container1">
              <p className="upload6">Upload</p>
              <p className="spotify-podcast1">Spotify Podcast</p>
            </b>
          </div>
          {showFrameDiv && (
            <div
              className="upload-media-or-text-file-parent"
              style={frameDiv1Style}
            >
              <b className="upload-media-or-container">
                <span className="upload-media-or-container1">
                  <p className="upload-media">Upload Media</p>
                  <p className="or-text-file">or Text File</p>
                </span>
              </b>
              <div className="file-icon-wrapper" style={frameDiv2Style}>
                <div className="file-icon" style={fileIconStyle}>
                  <img
                    className="upload-icon2"
                    loading="lazy"
                    alt=""
                    src="/vector2.svg"
                  />
                  <img
                    className="component-status-icon"
                    alt=""
                    src="/vector3.svg"
                    style={componentStatusIconStyle}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      {isUploadYTOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeUploadYT}
        >
          <UploadYT onClose={closeUploadYT} />
        </PortalPopup>
      )}
      {isUploadSotifyOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeUploadSotify}
        >
          <UploadSotify onClose={closeUploadSotify} />
        </PortalPopup>
      )}
    </>
  );
};

FrameComponent2.propTypes = {
  className: PropTypes.string,
  showFrameDiv: PropTypes.bool,

  /** Style props */
  propWidth: PropTypes.any,
  propPadding: PropTypes.any,
  propFlex: PropTypes.any,
  propTextDecoration: PropTypes.any,
  propFontWeight: PropTypes.any,
  propFlex1: PropTypes.any,
  propPadding1: PropTypes.any,
  propMinWidth: PropTypes.any,
  propWidth1: PropTypes.any,
  propFlex2: PropTypes.any,
  propHeight: PropTypes.any,
  propPadding2: PropTypes.any,
  propFlex3: PropTypes.any,
  propMaxHeight: PropTypes.any,
  propHeight1: PropTypes.any,
};

export default FrameComponent2;
