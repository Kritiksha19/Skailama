import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./CreateProject.css";

const CreateProject = ({ className = "", onClose }) => {
  const navigate = useNavigate();

  const onButtonClick = useCallback(() => {
    navigate("/project-list");
  }, [navigate]);

  return (
    <div className={`create-project ${className}`}>
      <div className="create-project-wrapper">
        <b className="create-project1">Create Project</b>
      </div>
      <section className="enter-project-name-parent">
        <div className="enter-project-name">Enter Project Name:</div>
        <div className="input-field5">
          <input className="label" placeholder="Type Here" type="text" />
        </div>
        <div className="project-name-cant">Project Name Can’t be empty</div>
      </section>
      <div className="create-project-inner">
        <div className="frame-parent4">
          <div className="cancel-wrapper">
            <div className="cancel">Cancel</div>
          </div>
          <button className="button5" onClick={onButtonClick}>
            <div className="create">Create</div>
          </button>
        </div>
      </div>
    </div>
  );
};

CreateProject.propTypes = {
  className: PropTypes.string,
  onClose: PropTypes.func,
};

export default CreateProject;
