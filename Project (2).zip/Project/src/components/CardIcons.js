import { useState, useMemo, useCallback } from "react";
import UploadYT from "/";
import PortalPopup from "./PortalPopup";
import PropTypes from "prop-types";
import "./CardIcons.css";

const CardIcons = ({ className = "", propTop, propBottom }) => {
  const [isUploadYTOpen, setUploadYTOpen] = useState(false);
  const cardIcons1Style = useMemo(() => {
    return {
      top: propTop,
      bottom: propBottom,
    };
  }, [propTop, propBottom]);

  const openUploadYT = useCallback(() => {
    setUploadYTOpen(true);
  }, []);

  const closeUploadYT = useCallback(() => {
    setUploadYTOpen(false);
  }, []);

  return (
    <>
      <div
        className={`card-icons1 ${className}`}
        onClick={openUploadYT}
        style={cardIcons1Style}
      >
        <img className="rss-icon1" alt="" src="/rss1.svg" />
        <div className="upload-rss-feed-wrapper">
          <b className="upload-rss-feed-container">
            <p className="upload2">Upload</p>
            <p className="rss-feed">RSS Feed</p>
          </b>
        </div>
      </div>
      {isUploadYTOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeUploadYT}
        >
          <UploadYT onClose={closeUploadYT} />
        </PortalPopup>
      )}
    </>
  );
};

CardIcons.propTypes = {
  className: PropTypes.string,

  /** Style props */
  propTop: PropTypes.any,
  propBottom: PropTypes.any,
};

export default CardIcons;
