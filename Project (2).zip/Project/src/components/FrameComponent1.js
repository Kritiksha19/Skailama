import { useMemo } from "react";
import PropTypes from "prop-types";
import "./FrameComponent1.css";

const FrameComponent1 = ({
  className = "",
  podcastUploadFlowTextDecoration,
  projectsTextDecoration,
  divTextDecoration,
  onBackIconClick,
  onSettingsIconsContainer1Click,
}) => {
  const podcastUploadFlowStyle = useMemo(() => {
    return {
      textDecoration: podcastUploadFlowTextDecoration,
    };
  }, [podcastUploadFlowTextDecoration]);

  const projectsStyle = useMemo(() => {
    return {
      textDecoration: projectsTextDecoration,
    };
  }, [projectsTextDecoration]);

  const divStyle = useMemo(() => {
    return {
      textDecoration: divTextDecoration,
    };
  }, [divTextDecoration]);

  return (
    <div className={`rectangle-parent ${className}`}>
      <div className="rectangle-div" />
      <div className="frame-parent21">
        <div className="frame-parent22">
          <div className="screenshot-2024-05-31-130846-1-parent">
            <img
              className="screenshot-2024-05-31-130846-11"
              loading="lazy"
              alt=""
              src="/screenshot-20240531-130846-1@2x.png"
            />
            <div className="lama-wrapper">
              <a className="lama1">LAMA.</a>
            </div>
          </div>
          <div className="podcast-upload-flow" style={podcastUploadFlowStyle}>
            Podcast Upload Flow
          </div>
        </div>
        <div className="back-wrapper">
          <img
            className="back-icon"
            loading="lazy"
            alt=""
            src="/back.svg"
            onClick={onBackIconClick}
          />
        </div>
      </div>
      <div className="frame-parent23">
        <div className="settings-header-wrapper">
          <div className="settings-header">
            <div className="settings-icons">
              <div className="ellipse-parent">
                <div className="ellipse-div" />
                <div className="submenu">
                  <a className="empty-icon">1</a>
                </div>
              </div>
              <a className="projects" style={projectsStyle}>
                Projects
              </a>
            </div>
            <div
              className="settings-icons1"
              onClick={onSettingsIconsContainer1Click}
            >
              <div className="ellipse-group">
                <div className="frame-child1" />
                <div className="div" style={divStyle}>
                  2
                </div>
              </div>
              <div className="widget-configurations">Widget Configurations</div>
            </div>
            <div className="settings-icons2">
              <div className="ellipse-container">
                <div className="frame-child2" />
                <div className="div1">3</div>
              </div>
              <div className="deployment">Deployment</div>
            </div>
            <div className="settings-icons3">
              <div className="ellipse-parent1">
                <div className="frame-child3" />
                <div className="div2">4</div>
              </div>
              <div className="pricing">Pricing</div>
            </div>
          </div>
        </div>
        <img className="line-icon" loading="lazy" alt="" />
      </div>
      <div className="line-group">
        <img className="frame-child4" loading="lazy" alt="" />
        <div className="language-dropdown">
          <div className="setting-icon-parent">
            <div className="setting-icon">
              <div className="setting-icon-child" />
              <img
                className="group-icon1"
                loading="lazy"
                alt=""
                src="/group1.svg"
              />
            </div>
            <div className="setting">Setting</div>
          </div>
        </div>
      </div>
    </div>
  );
};

FrameComponent1.propTypes = {
  className: PropTypes.string,

  /** Style props */
  podcastUploadFlowTextDecoration: PropTypes.any,
  projectsTextDecoration: PropTypes.any,
  divTextDecoration: PropTypes.any,

  /** Action props */
  onBackIconClick: PropTypes.func,
  onSettingsIconsContainer1Click: PropTypes.func,
};

export default FrameComponent1;
