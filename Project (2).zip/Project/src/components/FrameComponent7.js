import { useMemo } from "react";
import PropTypes from "prop-types";
import "./FrameComponent7.css";

const FrameComponent7 = ({
  className = "",
  distanceFormBottomInPx,
  propPadding,
}) => {
  const frameDiv3Style = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  return (
    <div
      className={`distance-container-wrapper ${className}`}
      style={frameDiv3Style}
    >
      <div className="distance-container">
        <div className="distance-form-bottom">{distanceFormBottomInPx}</div>
        <div className="input-field-with-button4">
          <div className="field6">
            <input className="label8" placeholder="20" type="text" />
          </div>
        </div>
      </div>
    </div>
  );
};

FrameComponent7.propTypes = {
  className: PropTypes.string,
  distanceFormBottomInPx: PropTypes.string,

  /** Style props */
  propPadding: PropTypes.any,
};

export default FrameComponent7;
