import { useMemo } from "react";
import PropTypes from "prop-types";
import "./ChatIconSizeContainer.css";

const ChatIconSizeContainer = ({
  className = "",
  chatIconSize,
  label,
  propFlex,
  propAlignSelf,
}) => {
  const chatIconSizeContainerStyle = useMemo(() => {
    return {
      flex: propFlex,
      alignSelf: propAlignSelf,
    };
  }, [propFlex, propAlignSelf]);

  return (
    <div
      className={`chat-icon-size-container ${className}`}
      style={chatIconSizeContainerStyle}
    >
      <div className="chat-icon-size">{chatIconSize}</div>
      <div className="dropdown">
        <div className="label7">{label}</div>
        <img className="chevron-down-icon" alt="" src="/chevrondown.svg" />
      </div>
    </div>
  );
};

ChatIconSizeContainer.propTypes = {
  className: PropTypes.string,
  chatIconSize: PropTypes.string,
  label: PropTypes.string,

  /** Style props */
  propFlex: PropTypes.any,
  propAlignSelf: PropTypes.any,
};

export default ChatIconSizeContainer;
