import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import ProjectRow from "./ProjectRow";
import PropTypes from "prop-types";
import "./ProjectList1.css";

const ProjectList1 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onProjectRowContainerClick = useCallback(() => {
    navigate("/upload");
  }, [navigate]);

  const onProjectRowContainer1Click = useCallback(() => {
    navigate("/upload");
  }, [navigate]);

  const onProjectRowContainer2Click = useCallback(() => {
    navigate("/upload");
  }, [navigate]);

  const onProjectRowContainer3Click = useCallback(() => {
    navigate("/upload");
  }, [navigate]);

  const onProjectRowContainer4Click = useCallback(() => {
    navigate("/upload");
  }, [navigate]);

  const onProjectRowContainer5Click = useCallback(() => {
    navigate("/upload");
  }, [navigate]);

  const onProjectRowContainer6Click = useCallback(() => {
    navigate("/upload");
  }, [navigate]);

  const onProjectRowContainer7Click = useCallback(() => {
    navigate("/upload");
  }, [navigate]);

  const onProjectRowContainer8Click = useCallback(() => {
    navigate("/upload");
  }, [navigate]);

  return (
    <section className={`project-list1 ${className}`}>
      <div className="list-header">
        <ProjectRow onProjectRowContainerClick={onProjectRowContainerClick} />
        <ProjectRow
          propTop="0px"
          propLeft="414px"
          propPadding="0px 0px var(--padding-3xl)"
          propPadding1="var(--padding-3xs) var(--padding-9xs) var(--padding-3xs) var(--padding-smi)"
          propMargin="0"
          onProjectRowContainerClick={onProjectRowContainer1Click}
        />
        <ProjectRow
          propTop="0px"
          propLeft="828px"
          propPadding="0px 0px var(--padding-3xl)"
          propPadding1="var(--padding-3xs) var(--padding-9xs) var(--padding-3xs) var(--padding-smi)"
          propMargin="0"
          onProjectRowContainerClick={onProjectRowContainer2Click}
        />
        <ProjectRow
          propTop="219px"
          propLeft="0px"
          propPadding="0px 0px var(--padding-2xl)"
          propPadding1="var(--padding-3xs) var(--padding-9xs) var(--padding-2xs) var(--padding-smi)"
          propMargin="unset"
          onProjectRowContainerClick={onProjectRowContainer3Click}
        />
        <ProjectRow
          propTop="219px"
          propLeft="414px"
          propPadding="0px 0px var(--padding-2xl)"
          propPadding1="var(--padding-3xs) var(--padding-9xs) var(--padding-2xs) var(--padding-smi)"
          propMargin="0"
          onProjectRowContainerClick={onProjectRowContainer4Click}
        />
        <ProjectRow
          propTop="219px"
          propLeft="828px"
          propPadding="0px 0px var(--padding-2xl)"
          propPadding1="var(--padding-3xs) var(--padding-9xs) var(--padding-2xs) var(--padding-smi)"
          propMargin="0"
          onProjectRowContainerClick={onProjectRowContainer5Click}
        />
        <ProjectRow
          propTop="438px"
          propLeft="0px"
          propPadding="0px 0px var(--padding-2xl)"
          propPadding1="var(--padding-3xs) var(--padding-9xs) var(--padding-2xs) var(--padding-smi)"
          propMargin="unset"
          onProjectRowContainerClick={onProjectRowContainer6Click}
        />
        <ProjectRow
          propTop="438px"
          propLeft="414px"
          propPadding="0px 0px var(--padding-2xl)"
          propPadding1="var(--padding-3xs) var(--padding-9xs) var(--padding-2xs) var(--padding-smi)"
          propMargin="0"
          onProjectRowContainerClick={onProjectRowContainer7Click}
        />
        <ProjectRow
          propTop="438px"
          propLeft="828px"
          propPadding="0px 0px var(--padding-2xl)"
          propPadding1="var(--padding-3xs) var(--padding-9xs) var(--padding-2xs) var(--padding-smi)"
          propMargin="0"
          onProjectRowContainerClick={onProjectRowContainer8Click}
        />
      </div>
    </section>
  );
};

ProjectList1.propTypes = {
  className: PropTypes.string,
};

export default ProjectList1;
