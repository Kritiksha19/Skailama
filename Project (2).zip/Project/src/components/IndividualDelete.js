import { useMemo } from "react";
import PropTypes from "prop-types";
import "./IndividualDelete.css";

const IndividualDelete = ({
  className = "",
  propPadding,
  propPadding1,
  onButton2Click,
}) => {
  const component1Variant25Style = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const component1Variant28Style = useMemo(() => {
    return {
      padding: propPadding1,
    };
  }, [propPadding1]);

  return (
    <div className={`individual-delete ${className}`}>
      <div className="component-1variant25" style={component1Variant25Style}>
        <h3 className="done">Done</h3>
      </div>
      <div className="component-1variant28" style={component1Variant28Style}>
        <div className="standalone-delete">
          <button className="button11" onClick={onButton2Click}>
            <div className="edit">Edit</div>
          </button>
          <div className="button12">
            <div className="delete">Delete</div>
          </div>
        </div>
      </div>
    </div>
  );
};

IndividualDelete.propTypes = {
  className: PropTypes.string,

  /** Style props */
  propPadding: PropTypes.any,
  propPadding1: PropTypes.any,

  /** Action props */
  onButton2Click: PropTypes.func,
};

export default IndividualDelete;
