import ChatbotFieldLabels from "./ChatbotFieldLabels";
import PropTypes from "prop-types";
import "./ChatbotSettings.css";

const ChatbotSettings = ({ className = "" }) => {
  return (
    <div className={`chatbot-settings ${className}`}>
      <div className="chatbot-fields">
        <ChatbotFieldLabels chatbotName="Chatbot Name" />
        <ChatbotFieldLabels chatbotName="Welcome Message" />
        <div className="chatbot-name-field">
          <div className="chatbot-name-input">
            <h3 className="input-placeholder">Input Placeholder</h3>
            <div className="field5">
              <input className="label6" placeholder="Placeholder" type="text" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

ChatbotSettings.propTypes = {
  className: PropTypes.string,
};

export default ChatbotSettings;
