import { useState, useMemo, useCallback } from "react";
import UploadSotify from "./UploadSotify";
import PortalPopup from "./PortalPopup";
import PropTypes from "prop-types";
import "./CardIcons1.css";

const CardIcons1 = ({
  className = "",
  group,
  spotifyPodcast,
  propLeft,
  propGap,
  propWidth,
  propOverflow,
}) => {
  const [isUploadSotifyOpen, setUploadSotifyOpen] = useState(false);
  const cardIconsStyle = useMemo(() => {
    return {
      left: propLeft,
      gap: propGap,
      width: propWidth,
    };
  }, [propLeft, propGap, propWidth]);

  const groupIconStyle = useMemo(() => {
    return {
      overflow: propOverflow,
    };
  }, [propOverflow]);

  const openUploadSotify = useCallback(() => {
    setUploadSotifyOpen(true);
  }, []);

  const closeUploadSotify = useCallback(() => {
    setUploadSotifyOpen(false);
  }, []);

  return (
    <>
      <div
        className={`card-icons ${className}`}
        onClick={openUploadSotify}
        style={cardIconsStyle}
      >
        <img
          className="group-icon2"
          alt=""
          src={group}
          style={groupIconStyle}
        />
        <div className="card-labels">
          <b className="upload-spotify-podcast-container">
            <p className="upload1">Upload</p>
            <p className="spotify-podcast">{spotifyPodcast}</p>
          </b>
        </div>
      </div>
      {isUploadSotifyOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeUploadSotify}
        >
          <UploadSotify onClose={closeUploadSotify} />
        </PortalPopup>
      )}
    </>
  );
};

CardIcons1.propTypes = {
  className: PropTypes.string,
  group: PropTypes.string,
  spotifyPodcast: PropTypes.string,

  /** Style props */
  propLeft: PropTypes.any,
  propGap: PropTypes.any,
  propWidth: PropTypes.any,
  propOverflow: PropTypes.any,
};

export default CardIcons1;
