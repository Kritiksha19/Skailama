import { useState, useCallback } from "react";
import CreateProject from "./CreateProject";
import PortalPopup from "./PortalPopup";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./Navigation1.css";

const Navigation1 = ({ className = "" }) => {
  const [isCreateProjectOpen, setCreateProjectOpen] = useState(false);
  const navigate = useNavigate();

  const onBackLinkContainerClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const openCreateProject = useCallback(() => {
    setCreateProjectOpen(true);
  }, []);

  const closeCreateProject = useCallback(() => {
    setCreateProjectOpen(false);
  }, []);

  return (
    <>
      <section className={`navigation1 ${className}`}>
        <div className="home-button-parent">
          <div className="home-button">
            <div className="back-link" onClick={onBackLinkContainerClick}>
              <h3 className="back-to-home1">Back to Home</h3>
              <div className="back-icon1">
                <img
                  className="back-icon-child"
                  alt=""
                  src="/rectangle-1.svg"
                />
                <img
                  className="background-icon"
                  loading="lazy"
                  alt=""
                  src="/vector-1.svg"
                />
              </div>
            </div>
          </div>
          <div className="projects-parent">
            <h1 className="projects1">Projects</h1>
            <div className="create-project2" onClick={openCreateProject}>
              <button className="button10">
                <div className="plus-icon">
                  <img className="shape-icon" alt="" src="/vector-31.svg" />
                </div>
                <div className="create-a-project1">Create a Project</div>
              </button>
            </div>
          </div>
        </div>
      </section>
      {isCreateProjectOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeCreateProject}
        >
          <CreateProject onClose={closeCreateProject} />
        </PortalPopup>
      )}
    </>
  );
};

Navigation1.propTypes = {
  className: PropTypes.string,
};

export default Navigation1;
