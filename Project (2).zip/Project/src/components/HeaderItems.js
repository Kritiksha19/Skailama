import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";
import "./HeaderItems.css";

const HeaderItems = ({ className = "" }) => {
  const navigate = useNavigate();

  const onHomeIconClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onSampleProjectClick = useCallback(() => {
    navigate("/project-list");
  }, [navigate]);

  return (
    <div className={`header-items ${className}`}>
      <div className="project-info">
        <div className="project-name-container">
          <div className="project-name2">
            <img
              className="home-icon2"
              loading="lazy"
              alt=""
              src="/home.svg"
              onClick={onHomeIconClick}
            />
            <a
              className="sample-project-container2"
              onClick={onSampleProjectClick}
            >
              <span>/ Sample Project /</span>
              <span className="span3">{`  `}</span>
              <span className="widget-configutation1">
                Widget Configutation
              </span>
            </a>
          </div>
        </div>
        <div className="language-selection">
          <div className="language-dropdown2">
            <div className="language-dropdown-icon-contain">
              <img
                className="language-dropdown-icon"
                loading="lazy"
                alt=""
                src="/vector1.svg"
              />
            </div>
            <div className="selected-language">
              <a className="en1">EN</a>
            </div>
            <div className="india1">
              <div className="country-selector-icons">
                <img className="country-icons" alt="" src="/vector-11.svg" />
                <img className="country-icons1" alt="" src="/vector-21.svg" />
                <img className="country-icons2" alt="" src="/vector-3.svg" />
                <img
                  className="group-icon6"
                  loading="lazy"
                  alt=""
                  src="/group-1.svg"
                />
              </div>
            </div>
          </div>
          <div className="notification-bell">
            <div className="bell-icon-container">
              <img
                className="icon-bell3"
                loading="lazy"
                alt=""
                src="/-icon-bell.svg"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

HeaderItems.propTypes = {
  className: PropTypes.string,
};

export default HeaderItems;
