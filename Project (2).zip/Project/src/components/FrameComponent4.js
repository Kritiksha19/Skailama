import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent5 from "./FrameComponent5";
import FrameComponent2 from "./FrameComponent2";
import CardIcons1 from "./CardIcons1";
import CardIcons from "./CardIcons";
import FrameComponent3 from "./FrameComponent3";
import PropTypes from "prop-types";
import "./FrameComponent4.css";

const FrameComponent4 = ({ className = "" }) => {
  const navigate = useNavigate();

  const onHomeIconClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onSampleProjectClick = useCallback(() => {
    navigate("/project-list");
  }, [navigate]);

  return (
    <section className={`drag-drop-area ${className}`}>
      <div className="header1">
        <FrameComponent5
          upload="Upload"
          propDebugCommit="unset"
          propDebugCommit1="unset"
          onHomeIconClick={onHomeIconClick}
          onSampleProjectClick={onSampleProjectClick}
        />
        <div className="select-file-button">
          <div className="upload-header">
            <h1 className="upload3">Upload</h1>
            <div className="upload-options">
              <div className="instance-parent">
                <FrameComponent2
                  showFrameDiv={false}
                  propWidth="unset"
                  propPadding="0px 0px var(--padding-120xl)"
                  propFlex="1"
                  propTextDecoration="unset"
                  propFontWeight="bold"
                  propFlex1="unset"
                  propPadding1="var(--padding-xs) var(--padding-8xs) var(--padding-xs) var(--padding-sm)"
                  propMinWidth="unset"
                  propWidth1="270px"
                  propFlex2="unset"
                  propHeight="73px"
                  propPadding2="unset"
                  propFlex3="unset"
                  propMaxHeight="unset"
                  propHeight1="61px"
                />
                <CardIcons1
                  group="/group-2.svg"
                  spotifyPodcast="Spotify Podcast"
                />
                <CardIcons1
                  group="/youtube1.svg"
                  spotifyPodcast="Youtube Video"
                  propLeft="20px"
                  propGap="17px"
                  propWidth="270px"
                  propOverflow="hidden"
                />
                <CardIcons />
                <CardIcons propTop="unset" propBottom="15px" />
              </div>
            </div>
          </div>
        </div>
        <FrameComponent3 />
        <div className="separator">
          <div className="dropzone">
            <div className="dropzone-child" />
            <div className="upload-options1">
              <div className="icons-wrapper">
                <div className="icons">
                  <img className="upload-icon1" alt="" src="/vector-41.svg" />
                  <img className="drag-drop-icon" alt="" src="/vector-5.svg" />
                </div>
              </div>
            </div>
            <p className="select-a-file-container">
              <span className="select-a-file-or-drag-and-dro">
                <span className="select-a">
                  Select a file or drag and drop here (Podcast Media or
                  Transcription Text)
                </span>
              </span>
              <span className="mp4-mov-mp3-wav-pdf-docx">
                <span>MP4, MOV, MP3, WAV, PDF, DOCX or TXT file</span>
              </span>
            </p>
            <div className="button-frame">
              <button className="button9">
                <b className="select-file">Select File</b>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

FrameComponent4.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent4;
