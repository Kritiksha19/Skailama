import HeaderItems from "./HeaderItems";
import ConfigurationOptions from "./ConfigurationOptions";
import ChatbotSettings from "./ChatbotSettings";
import PropTypes from "prop-types";
import "./HeaderContent.css";

const HeaderContent = ({ className = "" }) => {
  return (
    <div className={`header-content ${className}`}>
      <HeaderItems />
      <div className="configuration-title">
        <h1 className="configuration1">Configuration</h1>
      </div>
      <ConfigurationOptions />
      <ChatbotSettings />
    </div>
  );
};

HeaderContent.propTypes = {
  className: PropTypes.string,
};

export default HeaderContent;
