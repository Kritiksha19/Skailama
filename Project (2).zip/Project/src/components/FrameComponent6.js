import { useMemo } from "react";
import PropTypes from "prop-types";
import "./FrameComponent6.css";

const FrameComponent6 = ({
  className = "",
  frameDivTextDecoration,
  frameDivMargin,
  onBackIconClick,
  onFrameContainerClick,
}) => {
  const projects1Style = useMemo(() => {
    return {
      textDecoration: frameDivTextDecoration,
    };
  }, [frameDivTextDecoration]);

  const widgetConfigurationStyle = useMemo(() => {
    return {
      margin: frameDivMargin,
    };
  }, [frameDivMargin]);

  return (
    <div className={`rectangle-group ${className}`}>
      <div className="frame-child5" />
      <div className="navigation-column">
        <div className="nav-column-elements">
          <div className="nav-column-item">
            <img
              className="screenshot-2024-05-31-130846-13"
              loading="lazy"
              alt=""
              src="/screenshot-20240531-130846-1@2x.png"
            />
            <div className="l-a-m-a-nav-item">
              <a className="lama3">LAMA.</a>
            </div>
          </div>
          <div className="podcast-upload-flow1">Podcast Upload Flow</div>
        </div>
        <div className="back-button-container">
          <img
            className="back-icon2"
            loading="lazy"
            alt=""
            src="/back.svg"
            onClick={onBackIconClick}
          />
        </div>
      </div>
      <div className="content-area">
        <div className="breadcrumb-bar">
          <div className="breadcrumb-items">
            <div className="frame-parent25" onClick={onFrameContainerClick}>
              <div className="ellipse-parent2">
                <div className="frame-child6" />
                <a className="breadcrumb-separators">1</a>
              </div>
              <div className="projects2" style={projects1Style}>
                Projects
              </div>
            </div>
            <div className="frame-parent26">
              <div className="ellipse-parent3">
                <div className="frame-child7" />
                <div className="div3">2</div>
              </div>
              <p
                className="widget-configuration1"
                style={widgetConfigurationStyle}
              >
                Widget Configuration
              </p>
            </div>
            <div className="frame-parent27">
              <div className="ellipse-parent4">
                <div className="frame-child8" />
                <div className="div4">3</div>
              </div>
              <div className="deployment1">Deployment</div>
            </div>
            <div className="frame-parent28">
              <div className="ellipse-parent5">
                <div className="frame-child9" />
                <div className="div5">4</div>
              </div>
              <div className="pricing1">Pricing</div>
            </div>
          </div>
        </div>
        <img className="breadcrumb-divider-icon" loading="lazy" alt="" />
      </div>
      <div className="footer">
        <img className="footer-divider-icon" loading="lazy" alt="" />
        <div className="setting-item-wrapper">
          <div className="setting-item">
            <div className="setting-icon-container">
              <div className="setting-icon1" />
              <img
                className="group-icon5"
                loading="lazy"
                alt=""
                src="/group1.svg"
              />
            </div>
            <div className="setting1">Setting</div>
          </div>
        </div>
      </div>
    </div>
  );
};

FrameComponent6.propTypes = {
  className: PropTypes.string,

  /** Style props */
  frameDivTextDecoration: PropTypes.any,
  frameDivMargin: PropTypes.any,

  /** Action props */
  onBackIconClick: PropTypes.func,
  onFrameContainerClick: PropTypes.func,
};

export default FrameComponent6;
