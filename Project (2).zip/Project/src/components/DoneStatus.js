import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import IndividualDelete from "./IndividualDelete";
import PropTypes from "prop-types";
import "./DoneStatus.css";

const DoneStatus = ({ className = "" }) => {
  const navigate = useNavigate();

  const onButtonClick = useCallback(() => {
    navigate("/upload-transcript");
  }, [navigate]);

  const onButton2Click = useCallback(() => {
    navigate("/upload-transcript");
  }, [navigate]);

  const onButton3Click = useCallback(() => {
    navigate("/upload-transcript");
  }, [navigate]);

  const onButton4Click = useCallback(() => {
    navigate("/upload-transcript");
  }, [navigate]);

  return (
    <div className={`done-status ${className}`}>
      <div className="component-1variant29">
        <h3 className="done1">Done</h3>
      </div>
      <div className="property-value">
        <button className="component-1variant38">
          <b className="name3">Name</b>
        </button>
        <div className="detail-headers">
          <div className="component-1variant30">
            <h3 className="sample-name">Sample Name</h3>
          </div>
          <div className="component-1variant301">
            <h3 className="sample-name1">Sample Name</h3>
          </div>
        </div>
        <div className="component-1variant22">
          <h3 className="sample-name2">Sample Name</h3>
        </div>
        <div className="component-1variant21">
          <h3 className="sample-name3">Sample Name</h3>
        </div>
      </div>
      <div className="date-value">
        <div className="action-buttons">
          <div className="component-1variant35">
            <h2 className="update-date">{`Update Date & Time`}</h2>
          </div>
          <button className="component-1variant37">
            <b className="status">Status</b>
          </button>
          <button className="component-1variant36">
            <b className="action">Action</b>
          </button>
        </div>
        <div className="delete-button">
          <div className="delete-action-parent">
            <div className="delete-action">
              <div className="component-1variant34">
                <div className="jun-24">12 Jun 24 | 15:67</div>
              </div>
              <div className="component-1variant33">
                <div className="jun-241">12 Jun 24 | 15:67</div>
              </div>
            </div>
            <div className="component-1variant32">
              <div className="jun-242">12 Jun 24 | 15:67</div>
            </div>
            <div className="component-1variant31">
              <div className="jun-243">12 Jun 24 | 15:67</div>
            </div>
          </div>
          <div className="individual-edit">
            <div className="component-1variant211">
              <div className="edit-delete">
                <button className="button13" onClick={onButton4Click}>
                  <div className="edit1">Edit</div>
                </button>
                <div className="button14">
                  <div className="delete1">Delete</div>
                </div>
              </div>
            </div>
            <IndividualDelete onButton2Click={onButtonClick} />
            <IndividualDelete
              propPadding="var(--padding-6xl-3) var(--padding-53xl) var(--padding-6xl-4)"
              propPadding1="var(--padding-lgi-8) var(--padding-23xl) var(--padding-lgi-9)"
              onButton2Click={onButton2Click}
            />
            <IndividualDelete
              propPadding="var(--padding-6xl-3) var(--padding-53xl) var(--padding-6xl-4)"
              propPadding1="var(--padding-lgi-8) var(--padding-23xl) var(--padding-lgi-9)"
              onButton2Click={onButton3Click}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

DoneStatus.propTypes = {
  className: PropTypes.string,
};

export default DoneStatus;
