import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent5 from "./FrameComponent5";
import FrameComponent2 from "./FrameComponent2";
import DoneStatus from "./DoneStatus";
import PropTypes from "prop-types";
import "./ProjectContent.css";

const ProjectContent = ({ className = "" }) => {
  const navigate = useNavigate();

  const onHomeIconClick = useCallback(() => {
    navigate("/home-page");
  }, [navigate]);

  const onSampleProjectClick = useCallback(() => {
    navigate("/project-list");
  }, [navigate]);

  return (
    <div className={`project-content ${className}`}>
      <div className="frame-parent24">
        <FrameComponent5
          upload="Upload"
          onHomeIconClick={onHomeIconClick}
          onSampleProjectClick={onSampleProjectClick}
        />
        <div className="all-files-message">
          <div className="sample-project-parent">
            <h1 className="sample-project1">Sample Project</h1>
            <div className="component-header">
              <FrameComponent2 showFrameDiv />
            </div>
          </div>
        </div>
      </div>
      <div className="component-footer">
        <div className="component-message">
          <div className="component-action">
            <div className="all-files-are-container">
              <span className="all-files-are-container1">
                <span className="span2">{`            `}</span>
                <span className="all-files-are">
                  {" "}
                  All files are processed! Your widget is ready to go!
                </span>
              </span>
            </div>
          </div>
          <button className="button15">
            <b className="try-it-out">Try it Out!</b>
          </button>
        </div>
      </div>
      <div className="component-variant">
        <DoneStatus />
      </div>
    </div>
  );
};

ProjectContent.propTypes = {
  className: PropTypes.string,
};

export default ProjectContent;
