import PropTypes from "prop-types";
import "./ActionMode.css";

const ActionMode = ({ className = "", onButtonClick }) => {
  return (
    <div className={`action-mode ${className}`}>
      <div className="action-mode-child" />
      <div className="mode-options">
        <div className="mode-buttons">
          <div className="edit-mode-button">
            <button className="button8" onClick={onButtonClick}>
              <img className="edit-icon" alt="" src="/vector-4.svg" />
              <b className="edit-mode">Edit Mode</b>
            </button>
          </div>
          <div className="layer-mode-button">
            <div className="layer-icon" />
            <img
              className="layer-2-icon"
              loading="lazy"
              alt=""
              src="/layer-2.svg"
            />
          </div>
        </div>
        <div className="transcript-info">
          <div className="speaker-an-official-container">
            <p className="speaker">Speaker</p>
            <p className="an-official-transcript">
              An official transcript is a record of the grades or marks you
              earned at the university or college you currently attend or have
              previously attended. A transcript certificate is an essential
              document for students that supplements college and university
              applications. Understanding how to get a transcript certificate
              can help you apply for higher education or study abroad
              programmes.
            </p>
            <p className="in-this-article">
              In this article, we answer the question, 'What is a transcript
              certificate?', review the different types, find out how to get a
              transcript certificate, explore the ways to send a transcript for
              WES evaluation, highlight advantages of these certificates,
              provide tips to help when requesting one and examine a template
              and examples letter to help you write your own. You may be
              wondering, 'What is a transcript certificate?'. It is a
              certificate that serves as a supporting document for your
              educational credentials, such as the list of subjects you took at
              your college or university, marks scored in those subjects and the
              duration of the courses. It also contains important information,
            </p>
          </div>
        </div>
      </div>
      <div className="separator-container">
        <img
          className="separator-container-child"
          loading="lazy"
          alt=""
          src="/line-3.svg"
        />
      </div>
    </div>
  );
};

ActionMode.propTypes = {
  className: PropTypes.string,

  /** Action props */
  onButtonClick: PropTypes.func,
};

export default ActionMode;
