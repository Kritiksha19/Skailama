import PropTypes from "prop-types";
import "./FrameComponent.css";

const FrameComponent = ({ className = "" }) => {
  return (
    <section className={`frame-parent17 ${className}`}>
      <div className="frame-parent18">
        <div className="frame-parent19">
          <div className="frame-wrapper9">
            <div className="frame-parent20">
              <div className="youtube-wrapper">
                <img
                  className="youtube-icon"
                  loading="lazy"
                  alt=""
                  src="/youtube.svg"
                />
              </div>
              <div className="name2">Name:</div>
            </div>
          </div>
          <h2 className="upload-from-youtube">Upload from Youtube</h2>
        </div>
        <div className="cross-container">
          <img className="cross-icon2" loading="lazy" alt="" src="/cross.svg" />
        </div>
      </div>
      <input className="input-field6" type="text" />
    </section>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
